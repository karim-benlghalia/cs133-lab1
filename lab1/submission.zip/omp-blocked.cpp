// Header inclusions, if any...
#include <omp.h>
#include "lib/gemm.h"
#include <cstring>
// Using declarations, if any...
 #define blocking_size 32
void GemmParallelBlocked(const float a[kI][kK], const float b[kK][kJ],
                         float c[kI][kJ]) {
  int i, j, k, it, jt, kt;
  float temp;
  //int num;
  //int id;
    float buffer[blocking_size][blocking_size];
  //    memset(buffer,0,sizeof(float)*blocking_size*blocking_size);
  
  for (int i = 0; i < blocking_size; ++i) {
    for (int i = 0; i < blocking_size; ++i) {
    std::memset(buffer, 0, sizeof(float)*blocking_size*blocking_size);
    }
  }
  
   #pragma omp parallel for private(kt,jt,i,k,j,temp)
   
   //num=nk/omp_get_num_threads();
   //id=num*omp_get_thread_num();
   
   
  
   for (it=0; it<kI; it+=blocking_size){
     for (jt=0; jt<kJ; jt+=blocking_size){ 
    
      for (kt=0; kt<kK; kt+=blocking_size){
      for (i=it; i<it+blocking_size; i++) {
			for (k=kt; k<kt+blocking_size; k++) {
        temp=a[i][k];
        for (j=jt; j<jt+blocking_size; j++) {
			   buffer[i-it][j-jt] += temp*b[k][j];
        
			}
		}
   }
   }
   for (i=0; i<blocking_size; i++)
   c[it+i][jt] = buffer[i][0];
   //memcpy(&c[it+i][jt], &buffer[i][0], sizeof(float)*blocking_size);
   }
   }


}
