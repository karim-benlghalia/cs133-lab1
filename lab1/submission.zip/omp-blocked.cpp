// Header inclusions, if any...
#include <omp.h>
#include "lib/gemm.h"
#include <cstring>
// Using declarations, if any...
 
void GemmParallelBlocked(const float a[kI][kK], const float b[kK][kJ],
                         float c[kI][kJ]) {
// float temp;
// int i, j, k;
// int nCores=omp_get_max_threads();
// omp_set_num_threads(nCores);



}
