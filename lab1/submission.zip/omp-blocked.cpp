// Header inclusions, if any...
#include <omp.h>
#include "lib/gemm.h"
#include <cstring>
// Using declarations, if any...
#define blocking_size 32
void GemmParallelBlocked(const float a[kI][kK], const float b[kK][kJ],
                         float c[kI][kJ])
{
  omp_set_num_threads(32);
  int i, j, k;
  int b_i, b_j, b_k;
  int i_blocks = kI / blocking_size;
  int j_blocks = kJ / blocking_size;
  int k_blocks = kK / blocking_size;

#pragma omp parallel for private(i, j, k, b_i, b_j) schedule(static) 
  for (i = 0; i < kI; i += i_blocks)
  {
    for (j = 0; j < kJ; j += j_blocks)
    {
      for (k = 0; k < kK; k += k_blocks)
      {
        for (b_i = i; b_i < i + i_blocks; b_i++)
        {
          for (b_j = j; b_j < j + j_blocks; b_j++)
          {
            int sum = 0;
            for (b_k = k; b_k < k + k_blocks; b_k++)
            {
              sum += a[b_i][b_k] * b[b_k][b_j];
            }
            c[b_i][b_j] += sum;
          }
        }
      }
    }
  }
}
